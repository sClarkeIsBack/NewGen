import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm5ld2dlbmVyYXRpb24=')

name = b.b64decode('TmV3IEdlbmVyYXRpb24=')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')